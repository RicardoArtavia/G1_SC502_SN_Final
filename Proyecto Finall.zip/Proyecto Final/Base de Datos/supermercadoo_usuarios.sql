-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: supermercadoo
-- ------------------------------------------------------
-- Server version	8.0.39

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fecha_registro` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expire` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'','','$2y$10$q/2x4N8qrH3mYAu7.471nevG4du1SUNZlP0YIqOcrwN5HpJtIEy6y','2024-08-26 22:38:18',NULL,NULL),(2,'marisol','alinapaolafonseca18@gmail.com','$2y$10$NHXINFZ/Tosm.oq.ByrFd.rlX9A2EuVLDfdninicSJoKflCmmayQu','2024-08-26 22:41:26','120f8eb43a4c911d1ef240f6a263b18ff6c28cad6dd7567dfe9bd07726df1c236d46a6e82ec05592ec91a1a04e150a1720a2','2024-08-29 04:16:00'),(4,'Alina','fonseca18@gmail.com','$2y$10$/0iMUStRJtC5eHCZNFvKL.9zjXFXgm7E1R50/TAJyAV7BkUTy64Ou','2024-08-26 22:52:01',NULL,NULL),(5,'ALLAN','allanfonseca@gmail.com','$2y$10$ODioYh8x.II9KmHMVOab4.kBroqmdyCiSlb9mTZvIRqyD.SmwYWQK','2024-08-26 23:06:56',NULL,NULL),(6,'Alina','pf089475@gmail.com','$2y$10$fvglnk3DNWrXkqk6Fx3mNuMUf8kS8Y9dJkuE/Kd94.FqV/D6B1W1m','2024-08-27 04:23:34','3d9a3dbebbea5129cde98d52a4db2ab0dec389d0859be9079e03ed254c25ebd0e4ab7ea70ef2c859085ee6473e35f9526dcd','2024-08-27 13:23:43'),(7,'Paola','apaolafm6@gmail.com','$2y$10$yFjgEZSsDzySPOE61rVN9uw2sxO8DnDiq05Ni6JkVYZLS0lzuEive','2024-08-29 02:37:28',NULL,NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-31  9:40:15
