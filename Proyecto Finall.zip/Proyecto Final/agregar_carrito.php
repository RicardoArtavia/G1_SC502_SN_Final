<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $producto_id = $_POST['producto_id'];
    $producto_nombre = $_POST['producto_nombre'];
    $producto_precio = $_POST['producto_precio'];

    // Verificar si el carrito ya tiene ese producto
    if (isset($_SESSION['carrito'][$producto_id])) {
        // Incrementar la cantidad del producto
        $_SESSION['carrito'][$producto_id]['cantidad']++;
    } else {
        // Agregar un nuevo producto al carrito
        $_SESSION['carrito'][$producto_id] = [
            'nombre' => $producto_nombre,
            'precio' => $producto_precio,
            'cantidad' => 1
        ];
    }

    // Redirigir al carrito después de agregar el producto
    header('Location: carrito.php');
    exit();
}
?>
