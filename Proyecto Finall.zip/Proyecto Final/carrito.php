<<?php
session_start();
require 'conexion.php'; // Asegúrate de tener tu archivo de conexión

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['nombre'])) {
    // Recoger datos del formulario de pago
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $direccion = $conn->real_escape_string($_POST['direccion']);
    $tarjeta = $conn->real_escape_string($_POST['tarjeta']);
    $fecha_expiracion = $conn->real_escape_string($_POST['fecha-expiracion']);
    $cvv = $conn->real_escape_string($_POST['cvv']);
    $total = $_POST['total']; // Usar el total calculado del carrito

    // Insertar el pago en la base de datos
    $sql = "INSERT INTO pagos (nombre, direccion, tarjeta, fecha_expiracion, cvv, total) VALUES ('$nombre', '$direccion', '$tarjeta', '$fecha_expiracion', '$cvv', '$total')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Pago registrado con éxito. Gracias por tu compra.');</script>";
        // Vaciar carrito después de realizar el pago
        unset($_SESSION['carrito']);
    } else {
        echo "Error al registrar el pago: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrito de Compras</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            width: 90%;
            max-width: 800px;
            background-color: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            position: relative;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid #ddd;
            padding: 15px;
            text-align: left;
        }

        th {
            background-color: #f8f9fa;
            color: #333;
            font-weight: bold;
        }

        td {
            background-color: #ffffff;
        }

        .total {
            text-align: right;
            margin-top: 20px;
            font-size: 20px;
            font-weight: bold;
            color: #333;
        }

        .boton-vaciar, .boton-pagar, .boton-volver, .boton-categorias {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 20px;
            text-decoration: none;
            display: inline-block;
        }

        .boton-vaciar {
            background-color: #ff4d4d;
            color: white;
            margin-right: 10px;
        }

        .boton-vaciar:hover {
            background-color: #cc0000;
        }

        .boton-volver {
            background-color: #007bff;
            color: white;
            margin-right: 10px;
        }

        .boton-volver:hover {
            background-color: #0056b3;
        }

        .boton-pagar {
            background-color: #28a745;
            color: white;
        }

        .boton-pagar:hover {
            background-color: #218838;
        }

        .boton-categorias {
            background-color: #f39c12;
            color: white;
            margin-left: 10px;
        }

        .boton-categorias:hover {
            background-color: #e67e22;
        }

        /* Estilos del formulario de pago */
        .formulario-pago {
            display: none;
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            margin-top: 30px;
        }

        .formulario-pago input, .formulario-pago textarea {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .formulario-pago label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
        }

        .formulario-pago button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .formulario-pago button:hover {
            background-color: #0056b3;
        }

        /* Estilos de la superposición de carga */
        .overlay {
            display: none; /* Oculto por defecto */
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            justify-content: center;
            align-items: center;
            z-index: 1000;
            color: white;
            font-size: 24px;
        }

        .spinner {
            border: 8px solid #f3f3f3; /* Light grey */
            border-top: 8px solid #3498db; /* Blue */
            border-radius: 50%;
            width: 60px;
            height: 60px;
            animation: spin 2s linear infinite;
            margin-top: 20px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
    <script>
        function mostrarFormularioPago() {
            const formularioPago = document.getElementById('formulario-pago');
            formularioPago.style.display = 'block';
        }

        function confirmarPago(event) {
            event.preventDefault(); // Evita que se envíe el formulario

            // Mostrar la superposición de carga
            const overlay = document.getElementById('overlay');
            overlay.style.display = 'flex';

            // Ocultar la superposición de carga después de 3 segundos
            setTimeout(() => {
                overlay.style.display = 'none';
                document.querySelector('#formulario-pago form').submit();
            }, 3000);
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Carrito de Compras</h2>
        <?php if (isset($_SESSION['carrito']) && !empty($_SESSION['carrito'])): ?>
            <table>
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total = 0;
                    foreach ($_SESSION['carrito'] as $producto_id => $producto) {
                        $subtotal = $producto['precio'] * $producto['cantidad'];
                        $total += $subtotal;
                        echo "<tr>";
                        echo "<td>{$producto['nombre']}</td>";
                        echo "<td>₡{$producto['precio']}</td>";
                        echo "<td>{$producto['cantidad']}</td>";
                        echo "<td>₡$subtotal</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
            <div class="total">
                <span>Total: ₡<?php echo $total; ?></span>
            </div>
            <form action="vaciar_carrito.php" method="post" style="display: inline;">
                <button type="submit" class="boton-vaciar">Vaciar Carrito</button>
            </form>
            <a href="productos.php" class="boton-volver">Volver a Productos</a>
            <a href="categorias.php" class="boton-categorias">Ir a Categorías</a>
            <!-- Botón de pagar -->
            <button class="boton-pagar" onclick="mostrarFormularioPago()">Pagar</button>

            <!-- Formulario de pago -->
            <div id="formulario-pago" class="formulario-pago">
                <h3>Detalles de Pago</h3>
                <form method="post" onsubmit="confirmarPago(event)">
                    <label for="nombre">Nombre Completo:</label>
                    <input type="text" id="nombre" name="nombre" required>
                    
                    <label for="direccion">Dirección de Envío:</label>
                    <textarea id="direccion" name="direccion" rows="3" required></textarea>
                    
                    <label for="tarjeta">Número de Tarjeta:</label>
                    <input type="text" id="tarjeta" name="tarjeta" required>
                    
                    <label for="fecha-expiracion">Fecha de Expiración:</label>
                    <input type="text" id="fecha-expiracion" name="fecha-expiracion" placeholder="MM/AA" required>
                    
                    <label for="cvv">CVV:</label>
                    <input type="text" id="cvv" name="cvv" required>
                    
                    <input type="hidden" name="total" value="<?php echo $total; ?>">
                    
                    <button type="submit">Confirmar Pago</button>
                </form>
            </div>
        <?php else: ?>
            <p style="text-align: center;">El carrito está vacío.</p>
        <?php endif; ?>
    </div>

    <!-- Superposición de carga -->
    <div id="overlay" class="overlay">
        <div>
            Procesando tu pago...
            <div class="spinner"></div>
        </div>
    </div>
</body>
</html>