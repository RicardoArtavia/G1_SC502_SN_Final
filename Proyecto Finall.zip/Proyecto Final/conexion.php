<?php
$servername = "localhost";
$username = "root"; // Cambia esto si usas otro nombre de usuario
$password = "bolita2078**"; // Tu contraseña
$dbname = "Supermercadoo"; // Nombre de la base de datos

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname, 3307);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
