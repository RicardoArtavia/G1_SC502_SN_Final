<?php

require_once '../models/ClubModel.php';

class ClubController
{
    private $model;

    public function __construct()
    {
        $this->model = new ClubModel();
        if (!$this->model) {
            die('Error al crear la instancia de ClubModel. Verifica la clase.');
        }
    }

    public function registrarUsuario()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'];
            $email = $_POST['email'];

            if ($this->model->registrarUsuario($nombre, $email)) {
                header('Location: ../views/inscripcion.php?success=true');
                exit();
            } else {
                header('Location: ../views/inscripcion.php?success=false');
                exit();
            }
        }
    }
}

// Manejo de la acción
if (isset($_POST['action']) && $_POST['action'] === 'registrarUsuario') {
    $controller = new ClubController();
    $controller->registrarUsuario();
}
?>
