<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supermercado</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Estilos generales */
        .whatsapp-float {
            position: fixed;
            width: 60px;
            height: 60px;
            bottom: 40px;
            right: 40px;
            background-color: #25d366;
            color: #FFF;
            border-radius: 50px;
            text-align: center;
            font-size: 30px;
            box-shadow: 2px 2px 3px #999;
            z-index: 100;
        }

        .whatsapp-icon {
            margin-top: 16px;
        }

        .user-cart-icons {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-icon {
            font-size: 20px;
            color: #9bce21;
            cursor: pointer;
        }

        .mi-cuenta-btn {
            font-size: 16px;
            color: #9bce21;
            background-color: transparent;
            border: none;
            cursor: pointer;
            position: relative;
        }

        .mi-cuenta-dropdown {
            display: none;
            position: absolute;
            top: 30px;
            right: 0;
            background-color: white;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            z-index: 200;
            padding: 10px 0;
        }

        .mi-cuenta-dropdown a {
            display: block;
            padding: 10px 20px;
            color: #111;
            text-decoration: none;
        }

        .mi-cuenta-dropdown a:hover {
            background-color: #f0f0f0;
        }

        .mi-cuenta-dropdown .close-dropdown {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 18px;
            color: #333;
            cursor: pointer;
        }

        .mi-cuenta-dropdown .close-dropdown:hover {
            color: #ff0000;
        }

        /* Estilos para el modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 400px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .modal-content form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .modal-content input[type="email"],
        .modal-content input[type="password"],
        .modal-content input[type="text"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .modal-content button {
            background-color: #00b894;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
        }

        .modal-content a {
            color: #00b894;
            text-align: center;
            margin-top: 10px;
            text-decoration: none;
            cursor: pointer;
        }

        /* Estilos específicos para la sección de productos */
        .box-container {
            margin-top: 55px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .box {
            border-top: 2px solid #9bce21;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
            background-color: #f6fafb;
            display: none;
        }

        .box img {
            height: 200px;
        }

        .product-txt h3 {
            font-size: 20px;
            color: #111419;
            margin-bottom: 10px;
        }

        .product-txt p {
            margin-bottom: 25px;
            color: #515557;
        }

        .precio {
            font-size: 17px;
            font-weight: 700;
            color: #ff9100 !important;
        }

        .btn-2, .btn-3 {
            background-color: #9bce21;
            margin-top: 50px;
            display: inline-block;
            padding: 11px 35px;
            border-radius: 25px;
            color: #ffffff;
            font-size: 16px;
            cursor: pointer;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }

        .btn-2:hover, .btn-3:hover, .btn-1:hover {
            background-color: #13462e;
        }

        .btn-3 {
            margin: 0;
            padding: 8px 25px;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    
    <header class="header">
        <div class="menu container">
            <a href="#" class="Logo">
                <svg xmlns="http://www.w3.org/2000/svg" width="40px" height="40px" fill="#9bce21" class="bi bi-shop" viewBox="0 0 16 16">
                    <path d="M2.97 1.35A1 1 0 0 1 3.73 1h8.54a1 1 0 0 1 .76.35l2.609 3.044A1.5 1.5 0 0 1 16 5.37v.255a2.375 2.375 0 0 1-4.25 1.458A2.37 2.37 0 0 1 9.875 8 2.37 2.37 0 0 1 8 7.083 2.37 2.37 0 0 1 6.125 8a2.37 2.37 0 0 1-1.875-.917A2.375 2.375 0 0 1 0 5.625V5.37a1.5 1.5 0 0 1 .361-.976zm1.78 4.275a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0 1.375 1.375 0 1 0 2.75 0V5.37a.5.5 0 0 0-.12-.325L12.27 2H3.73L1.12 5.045A.5.5 0 0 0 1 5.37v.255a1.375 1.375 0 0 0 2.75 0 .5.5 0 0 1 1 0M1.5 8.5A.5.5 0 0 1 2 9v6h1v-5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v5h6V9a.5.5 0 0 1 1 0v6h.5a.5.5 0 0 1 0 1H.5a.5.5 0 0 1 0-1H1V9a.5.5 0 0 1 .5-.5M4 15h3v-5H4zm5-5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1zm3 0h-2v3h2z"/>
                </svg>
            </a>
            <input type="checkbox" id="menu"/>
            <label for="menu">
                <img src="FOTOS DEL SUPER/menu.png" class="menu-icono" alt="menu">
            </label>
            <nav class="navbar">
                <ul>
                    <li><a href="Club de Fidelidad.html">Club de Fidelidad</a></li>
                    <li><a href="productos.html">Productos</a></li>
                    <li><a href="categorias.html">Categorías</a></li>
                    <li><a href="faq.html">Preguntas Frecuentes</a></li>
                </ul>
            </nav>
            <div class="user-cart-icons">
                <i class="fas fa-user user-icon" id="user-icon"></i>
                <a href="carrito.php">
                    <img id="img-carrito" src="FOTOS DEL SUPER/car.svg" alt="carrito">
                </a>
                <button class="mi-cuenta-btn" id="mi-cuenta-btn">Mi Cuenta</button>
                <div class="mi-cuenta-dropdown" id="mi-cuenta-dropdown">
                    <span class="close-dropdown">&times;</span>
                    <a href="perfil.html">Mi Perfil</a>
                    <a href="historial_compras.html">Historial de Compras</a>
                    <a href="lista_compras.html">Lista de Compras</a>
                    <a href="direcciones_entrega.html">Direcciones de Entrega</a>
                    <a href="metodos_pago.html">Métodos de Pago</a>
                </div>
            </div>
        </div>
        <div class="header-content container">
            <div class="header-txt">
                <span>¡Bienvenidos a Tu Supermercado de Confianza!</span>
                <h1>Ofertas Especiales</h1>
                <p>
                    En nuestro supermercado, queremos que disfrutes de la mejor
                    calidad al mejor precio. Por eso, hemos preparado una 
                    selección de ofertas especiales
                    que no puedes dejar pasar. ¡Descubre cómo ahorrar
                    mientras llenas tu carrito con productos de primera!
                </p>
                <div class="butons">
                    <a href="informacion.html" class="btn-1">Información</a>
                    <a href="#" class="btn-1">Leer más</a>
                </div>
            </div>
            <div class="header-img">
                <img src="FOTOS DEL SUPER/bag.png" alt="">
            </div>
        </div>
    </header>

    <section class="oferts container">
        <div class="ofert-1 b1">
            <div class="ofert-txt">
                <h3>¡Bienvenidos a un Mundo de Frescura y Sabor!
                    Descubre la Mejor Selección de Frutas y Verduras
                    En nuestro supermercado, nos enorgullece ofrecerte una 
                    variedad insuperable de frutas y verduras frescas, 
                    seleccionadas cuidadosamente para llevar lo mejor del 
                    campo a tu mesa.</h3>
                <a href="#">Leer mas</a>
            </div>
            <div class="ofert-img">
                <img src="FOTOS DEL SUPER/s1.png" alt="">
            </div>
        </div>
        <div class="ofert-1 b2">
            <div class="ofert-txt">
                <h3>¡Refresca tu Vida con Nuestros Jugos Naturales!
                    Sabores que Nutren y Refrescan
                    En nuestro supermercado, nos apasiona ofrecerte lo
                    mejor de la naturaleza en cada vaso.</h3>
                <a href="#">Leer mas</a>
            </div>
            <div class="ofert-img">
                <img src="FOTOS DEL SUPER/s2.png" alt="">
            </div>
        </div>
        <div class="ofert-1 b3">
            <div class="ofert-txt">
                <h3>Nutrición y Sabor para un Desayuno Perfecto
                    En nuestro supermercado, sabemos lo importante que es empezar
                    el día con el pie derecho. Por eso, te ofrecemos 
                    la mejor selección de leche y cereales,
                    ideales para un desayuno nutritivo 
                    y delicioso.</h3>
                <a href="#">Leer mas</a>
            </div>
            <div class="ofert-img">
                <img src="FOTOS DEL SUPER/s3.png" alt="">
            </div>
        </div>
    </section>

    <main class="products container">
        <h2>Productos en Oferta</h2>

        <div class="box-container" id="lista-1">
            <div class="box">
                <img src="FOTOS DEL SUPER/p1.png" alt="">
                <div class="product-txt">
                    <h3>Natilla Dos Pinos</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡3000</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="1">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p2.png" alt="">
                <div class="product-txt">
                    <h3>Vino</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡15000</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="2">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p3.png" alt="">
                <div class="product-txt">
                    <h3>Queso Turrialba</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡7000</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="3">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p4.png" alt="">
                <div class="product-txt">
                    <h3>Chorizo</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡8500</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="4">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p5.png" alt="">
                <div class="product-txt">
                    <h3>Yogurt Griego</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡6000</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="5">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p14.png" alt="">
                <div class="product-txt">
                    <h3>Nivea</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡4000</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="6">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p15.png" alt="">
                <div class="product-txt">
                    <h3> Coca Cola Jack Daniel's </h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡2000</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="7">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p8.png" alt="">
                <div class="product-txt">
                    <h3>Surtido de lomo</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡8000</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="8">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p17.png" alt="">
                <div class="product-txt">
                    <h3>Galletas libre de Grasa</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡1700</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="9">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p10.png" alt="">
                <div class="product-txt">
                    <h3>Helado de Chocolate</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡2500</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="10">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p11.png" alt="">
                <div class="product-txt">
                    <h3>Helado deslactosado</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡8590</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="11">Agregar al carrito</a>
                </div>
            </div>

            <div class="box">
                <img src="FOTOS DEL SUPER/p12.png" alt="">
                <div class="product-txt">
                    <h3>Vino Blanco</h3>
                    <p>Calidad Primium</p>
                    <p class="Precio">₡18000</p>
                    <a href="#" class="agregar-carrito btn-3" data-id="12">Agregar al carrito</a>
                </div>
            </div>
        </div>
        <div class="btn-2" id="load-more">Cargar Mas</div>
    </main>

    <section class="testimonial container">
        <span>Testimonios</span>
        <h2>Que Opinan Nuestros Clientes</h2>
        <div class="testimonial-content">
            <div class="testimonial-1">
                <p>
                    "Desde que descubrí este supermercado, mi experiencia de
                    compra ha cambiado por completo. La calidad de los productos es insuperable,
                    especialmente en la sección de frutas y verduras, donde siempre encuentro productos
                    frescos y de temporada. Los precios son muy competitivos, lo cual es genial para mi presupuesto 
                    mensual. Además, el personal siempre está dispuesto a ayudarme a encontrar lo que necesito, y su amabilidad
                    hace que cada visita sea un placer. Las ofertas y promociones semanales son increíbles y me han ayudado a ahorrar
                    una cantidad significativa de dinero. Sin duda, este supermercado se ha convertido en mi lugar favorito para hacer
                    las compras, y siempre lo recomiendo a mis amigos y familiares."
                </p>
                <img src="FOTOS DEL SUPER/starts.png" alt="">
                <h4>Lorena Fonseca</h4>
            </div>

            <div class="testimonial-1">
                <p>
                    "Este supermercado ha superado todas mis expectativas. La primera vez que visité la tienda,
                    quedé impresionado por la limpieza y la organización. Los pasillos están bien señalizados, 
                    lo que facilita encontrar cualquier producto. La sección de alimentos orgánicos y saludables es
                    especialmente notable, ya que ofrece una amplia gama de opciones para quienes nos preocupamos 
                    por una alimentación sana. Además, el servicio al cliente es excepcional; cada vez que he tenido 
                    una pregunta o necesitaba ayuda, el personal ha sido muy atento y profesional. También aprecio mucho 
                    las opciones de compra en línea y entrega a domicilio, que han sido de gran ayuda en mi ajetreado día a día. 
                    En resumen, este supermercado no solo cumple con mis necesidades de compra, 
                    sino que también mejora mi calidad de vida con su excelente servicio y productos de alta calidad."
                </p>
                <img src="FOTOS DEL SUPER/starts.png" alt="">
                <h4>Carlos Navarro</h4>
            </div>
        </div>
    </section>

    <footer class="footer">
        <div class="footer-content container">
            <div class="link">
                <h3>Redes Sociales</h3>
                <ul>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 16 16">
                        <path d="M13.601 2.326A7.85 7.85 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.9 7.9 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.9 7.9 0 0 0 13.6 2.326zM7.994 14.521a6.6 6.6 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.56 6.56 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592m3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.73.73 0 0 0-.529.247c-.182.198-.691.677-.691 1.654s.71 1.916.81 2.049c.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232"/>
                      </svg> +506-2268-1479</a></li>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                        <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.9 3.9 0 0 0-1.417.923A3.9 3.9 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.9 3.9 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.9 3.9 0 0 0-.923-1.417A3.9 3.9 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599s.453.546.598.92c.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.5 2.5 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.5 2.5 0 0 1-.92-.598 2.5 2.5 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233s.008-2.388.046-3.231c.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92s.546-.453.92-.598c.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92m-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217m0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334"/>
                      </svg> @supermercado</i></a></li>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-facebook" viewBox="0 0 16 16">
                        <path d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951"/>
                      </svg> Supermercado</a></li>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-tiktok" viewBox="0 0 16 16">
                        <path d="M9 0h1.98c.144.715.54 1.617 1.235 2.512C12.895 3.389 13.797 4 15 4v2c-1.753 0-3.07-.814-4-1.829V11a5 5 0 1 1-5-5v2a3 3 0 1 0 3 3z"/>
                      </svg> Supermercado</a></li>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-at-fill" viewBox="0 0 16 16">
                        <path d="M2 2A2 2 0 0 0 .05 3.555L8 8.414l7.95-4.859A2 2 0 0 0 14 2zm-2 9.8V4.698l5.803 3.546zm6.761-2.97-6.57 4.026A2 2 0 0 0 2 14h6.256A4.5 4.5 0 0 1 8 12.5a4.49 4.49 0 0 1 1.606-3.446l-.367-.225L8 9.586zM16 9.671V4.697l-5.803 3.546.338.208A4.5 4.5 0 0 1 12.5 8c1.414 0 2.675.652 3.5 1.671"/>
                        <path d="M15.834 12.244c0 1.168-.577 2.025-1.587 2.025-.503 0-1.002-.228-1.12-.648h-.043c-.118.416-.543.643-1.015.643-.77 0-1.259-.542-1.259-1.434v-.529c0-.844.481-1.4 1.26-1.4.585 0 .87.333.953.63h.03v-.568h.905v2.19c0 .272.18.42.411.42.315 0 .639-.415.639-1.39v-.118c0-1.277-.95-2.326-2.484-2.326h-.04c-1.582 0-2.64 1.067-2.64 2.724v.157c0 1.867 1.237 2.654 2.57 2.654h.045c.507 0 .935-.07 1.18-.18v.731c-.219.1-.643.175-1.237.175h-.044C10.438 16 9 14.82 9 12.646v-.214C9 10.36 10.421 9 12.485 9h.035c2.12 0 3.314 1.43 3.314 3.034zm-4.04.21v.227c0 .586.227.8.581.8.31 0 .564-.17.564-.743v-.367c0-.516-.275-.708-.572-.708-.346 0-.573.245-.573.791"/>
                      </svg> Supermecado@gmail.com</a></li>
                </ul>
            </div>

            <div class="link">
                <h3>Horarios</h3>
                <ul>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
                        <path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10m0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6"/>
                      </svg> Heredia, San Isidro</a></li>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-clock-fill" viewBox="0 0 16 16">
                        <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0M8 3.5a.5.5 0 0 0-1 0V9a.5.5 0 0 0 .252.434l3.5 2a.5.5 0 0 0 .496-.868L8 8.71z"/>
                      </svg> 8am-9:30pm</a></li>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-calendar-event-fill" viewBox="0 0 16 16">
                        <path d="M4 .5a.5.5 0 0 0-1 0V1H2a2 2 0 0 0-2 2v1h16V3a2 2 0 0 0-2-2h-1V.5a.5.5 0 0 0-1 0V1H4zM16 14V5H0v9a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2M12.5-7h1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-1a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5"/>
                      </svg> Lunes-Domingo</a></li>
                </ul>
            </div>

            <div class="link">
                <h3>Métodos de Pago</h3>
                <ul>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-credit-card-fill" viewBox="0 0 16 16">
                        <path d="M0 4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v1H0zm0 3v5a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7zm3 2h1a1 1 0 0 1 1 1v1a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1v-1a1 1 0 0 1 1-1"/>
                      </svg> Tarjetas de Credito</a></li>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paypal" viewBox="0 0 16 16">
                        <path d="M14.06 3.713c1.037-.61 1.037-2.137 0-2.748L11.528 5.04 8.32 8l3.207 2.96zm-3.595 2.116L7.583 8.68 1.03 14.73c.201 1.029 1.36 1.61 2.303 1.055zM1 13.396V2.603L6.846 8zM1.03 1.27l6.553 6.05 3.044-2.81L3.333.215C2.39-.341 1.231.24 1.03 1.27"/>
                      </svg> Paypal</a></li>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-phone" viewBox="0 0 16 16">
                        <path d="M11 1a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1zM5 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2z"/>
                        <path d="M8 14a1 1 0 1 0 0-2 1 1 0 0 0 0 2"/>
                      </svg> SinpeMóvil</a></li>
                </ul>
            </div>

            <div class="link">
                <h3>Descargue Nuestra Aplicación para hacer sus Pedidos.</h3>
                <ul>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-google-play" viewBox="0 0 16 16">
                        <path d="M14.222 9.374c1.037-.61 1.037-2.137 0-2.748L11.528 5.04 8.32 8l3.207 2.96zm-3.595 2.116L7.583 8.68 1.03 14.73c.201 1.029 1.36 1.61 2.303 1.055zM1 13.396V2.603L6.846 8zM1.03 1.27l6.553 6.05 3.044-2.81L3.333.215C2.39-.341 1.231.24 1.03 1.27"/>
                      </svg> SuperMercado</a></li>
                    <li><a href="#"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-apple" viewBox="0 0 16 16">
                        <path d="M11.182.008C11.148-.03 9.923.023 8.857 1.18c-1.066 1.156-.902 2.482-.878 2.516s1.52.087 2.475-1.258.762-2.391.728-2.43m3.314 11.733c-.048-.096-2.325-1.234-2.113-3.422s1.675-2.789 1.698-2.854-.597-.79-1.254-1.157a3.7 3.7 0 0 0-1.563-.434c-.108-.003-.483-.095-1.254.116-.508.139-1.653.589-1.968.607-.316.018-1.256-.522-2.267-.665-.647-.125-1.333.131-1.824.328-.49.196-1.422.754-2.074 2.237-.652 1.482-.311 3.83-.067 4.56s.625 1.924 1.273 2.796c.576.984 1.34 1.667 1.659 1.899s1.219.386 1.843.067c.502-.308 1.408-.485 1.766-.472.357.013 1.061.154 1.782.539.571.197 1.111.115 1.652-.105.541-.221 1.324-1.059 2.238-2.758q.52-1.185.473-1.282"/>
                        <path d="M11.182.008C11.148-.03 9.923.023 8.857 1.18c-1.066 1.156-.902 2.482-.878 2.516s1.52.087 2.475-1.258.762-2.391.728-2.43m3.314 11.733c-.048-.096-2.325-1.234-2.113-3.422s1.675-2.789 1.698-2.854-.597-.79-1.254-1.157a3.7 3.7 0 0 0-1.563-.434c-.108-.003-.483-.095-1.254.116-.508.139-1.653.589-1.968.607-.316.018-1.256-.522-2.267-.665-.647-.125-1.333.131-1.824.328-.49.196-1.422.754-2.074 2.237-.652 1.482-.311 3.83-.067 4.56s.625 1.924 1.273 2.796c.576.984 1.34 1.667 1.659 1.899s1.219.386 1.843.067c.502-.308 1.408-.485 1.766-.472.357.013 1.061.154 1.782.539.571.197 1.111.115 1.652-.105.541-.221 1.324-1.059 2.238-2.758q.52-1.185.473-1.282"/>
                      </svg> Supermercado</a></li>
                </ul>
            </div>
        </div>


        
        <div class="copyright" style="background-color: #9bce21; text-align: center; color: white; padding: 10px 0;">
            © 2024 Supermercado. Todos los derechos reservados.
        </div>
    </footer>

    <a href="https://wa.me/50688289816" class="whatsapp-float" target="_blank">
        <i class="fab fa-whatsapp whatsapp-icon"></i>
    </a>

    <!-- Modal de Inicio de Sesión y Registro -->
    <div id="userModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <form id="login-form" action="login.php" method="POST">
                <label for="email">Correo Electrónico</label>
                <input type="email" id="email" name="email" required>
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" required>
                <button type="submit">Iniciar Sesión</button>
                <a href="#" id="forgot-password">Olvidé mi contraseña</a>
                <a id="toggle-create-account">Crear Cuenta</a>
            </form>
            
            <form id="create-account-form" action="registro.php" method="POST" style="display: none;">
                <label for="nombre">Nombre Completo</label>
                <input type="text" id="nombre" name="nombre" required>
                <label for="email">Correo Electrónico</label>
                <input type="email" id="email" name="email" required>
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" required>
                <button type="submit">Crear Cuenta</button>
                <a id="toggle-login">Iniciar Sesión</a>
            </form>
            
    </div>
    
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const loadMoreBtn = document.getElementById('load-more');
            const products = document.querySelectorAll('.box-container .box');
            let visibleItems = 8; 

            console.log("Número de productos detectados:", products.length);

            if (loadMoreBtn) {  
                loadMoreBtn.addEventListener('click', () => {
                    visibleItems += 4; 
                    const totalItems = products.length;

                    for (let i = 0; i < totalItems; i++) {
                        if (i < visibleItems) {
                            products[i].style.display = 'inline-block';
                        }
                    }

                    if (visibleItems >= totalItems) {
                        loadMoreBtn.style.display = 'none';
                    }
                });
            }

            const miCuentaBtn = document.querySelector('#mi-cuenta-btn');
            const miCuentaDropdown = document.querySelector('#mi-cuenta-dropdown');

            miCuentaBtn.addEventListener('click', () => {
                miCuentaDropdown.style.display = miCuentaDropdown.style.display === 'block' ? 'none' : 'block';
            });

            const closeDropdownBtn = document.querySelector('.close-dropdown');
            closeDropdownBtn.addEventListener('click', () => {
                miCuentaDropdown.style.display = 'none';
            });

            document.addEventListener('click', (event) => {
                if (!miCuentaBtn.contains(event.target) && !miCuentaDropdown.contains(event.target)) {
                    miCuentaDropdown.style.display = 'none';
                }
            });

            const faqButtons = document.querySelectorAll('.faq-button');

            faqButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const faqContent = button.nextElementSibling;

                    if (faqContent.style.display === 'block') {
                        faqContent.style.display = 'none';
                    } else {
                        document.querySelectorAll('.faq-content').forEach(content => {
                            content.style.display = 'none';
                        });

                        faqContent.style.display = 'block';
                    }
                });
            });
        });

        const modal = document.getElementById("userModal");
        const btn = document.getElementById("user-icon");
        const span = document.getElementsByClassName("close")[0];

        btn.onclick = function () {
            modal.style.display = "block";
        }

        span.onclick = function () {
            modal.style.display = "none";
        }

        window.onclick = function (event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        document.getElementById('toggle-create-account').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('login-form').style.display = 'none';
            document.getElementById('create-account-form').style.display = 'block';
        });

        document.getElementById('toggle-login').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('create-account-form').style.display = 'none';
            document.getElementById('login-form').style.display = 'block';
        });

        document.getElementById('forgot-password').addEventListener('click', function(event) {
            event.preventDefault();
            const email = document.getElementById('email').value;
            if (email) {
                fetch('forgot_password.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email: email })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Te hemos enviado un enlace para recuperar tu contraseña a tu correo electrónico.');
                    } else {
                        alert('Error: ' + data.message);
                    }
                });
            } else {
                alert('Por favor, ingresa tu correo electrónico para continuar.');
            }
        });
    </script>
</body>
</html>
<?php
// Aquí puedes incluir la lógica para mostrar mensajes de éxito o fallo
if (isset($_GET['registro'])) {
    if ($_GET['registro'] == 'exito') {
        echo "<p>¡Registro exitoso!</p>";
    } elseif ($_GET['registro'] == 'fallo') {
        echo "<p>Error en el registro. Inténtalo de nuevo.</p>";
    }
}
?>

