<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: iniciar_sesion.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mi Cuenta</title>
</head>
<body>
    <h2>Bienvenido, <?php echo $_SESSION['nombre']; ?></h2>
    <p>Este es tu panel de usuario.</p>
    <p><a href="cerrar_sesion.php">Cerrar Sesión</a></p>
</body>
</html>
