<?php

class ClubModel
{
    private $conn;

    public function __construct()
    {
        // Cambia los detalles de conexión según tu configuración
        $this->conn = new mysqli('localhost', 'root', 'bolita2078**', 'Supermercadoo', 3307); // Cambia las credenciales y puerto según tu configuración

        if ($this->conn->connect_error) {
            die('Conexión fallida: ' . $this->conn->connect_error);
        }
    }

    public function registrarUsuario($nombre, $email)
    {
        // Inicializamos puntos y nivel a 0 y 1, y la fecha de registro a la fecha actual
        $puntos = 0;
        $nivel = 1;
        $fecha_registro = date('Y-m-d H:i:s');

        $stmt = $this->conn->prepare("INSERT INTO club_fidelidad (nombre, email, puntos, nivel, fecha_registro) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('sssis', $nombre, $email, $puntos, $nivel, $fecha_registro);
        
        return $stmt->execute();
    }
}
?>
