<?php
session_start();
require 'conexion.php';


if (!isset($_SESSION['email'])) {
    header("Location: login.php"); 
}


$email = $_SESSION['email'];


$sql = "SELECT * FROM usuarios WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $usuario = $result->fetch_assoc();
} else {
  
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Mi Perfil</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f6fafb;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #9bce21;
            color: white;
            padding: 15px 20px;
            text-align: center;
        }

        section {
            max-width: 600px;
            margin: 30px auto;
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #9bce21;
            font-size: 24px;
            margin-bottom: 20px;
        }

        .profile-info {
            display: flex;
            align-items: center;
            gap: 20px;
            margin-bottom: 20px;
        }

        .profile-info img {
            border-radius: 50%;
            width: 100px;
            height: 100px;
            object-fit: cover;
        }

        .profile-info input[type="file"] {
            display: none;
        }

        .custom-file-upload {
            background-color: #9bce21;
            color: white;
            padding: 10px 20px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 16px;
        }

        p {
            font-size: 18px;
            line-height: 1.6;
            margin-bottom: 10px;
        }

        footer {
            text-align: center;
            margin: 20px 0;
        }

        footer a {
            color: #9bce21;
            text-decoration: none;
            font-weight: bold;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <header>
        <h1>Mi Perfil</h1>
    </header>
    <section>
        <h2>Información Personal</h2>
        <div class="profile-info">
            <img src="uploads/default-profile.png" alt="Foto de perfil" id="profile-pic">
            <div>
                <label for="file-upload" class="custom-file-upload">
                    Cambiar Foto
                </label>
                <input id="file-upload" type="file" onchange="previewAndSaveFile()">
            </div>
        </div>
        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($usuario['nombre']); ?></p>
        <p><strong>Correo Electrónico:</strong> <?php echo htmlspecialchars($usuario['email']); ?></p>
    </section>
    <footer>
        <a href="index.html">Volver a la página principal</a>
    </footer>

    <script>
      
        document.addEventListener('DOMContentLoaded', function() {
            const savedProfilePic = localStorage.getItem('profile-pic');
            if (savedProfilePic) {
                document.getElementById('profile-pic').src = savedProfilePic;
            }
        });

        function previewAndSaveFile() {
            const preview = document.getElementById('profile-pic');
            const file = document.getElementById('file-upload').files[0];
            const reader = new FileReader();

            reader.addEventListener("load", function () {
                preview.src = reader.result;
                localStorage.setItem('profile-pic', reader.result);
            }, false);

            if (file) {
                reader.readAsDataURL(file);
            }
        }
    </script>
</body>
</html>
