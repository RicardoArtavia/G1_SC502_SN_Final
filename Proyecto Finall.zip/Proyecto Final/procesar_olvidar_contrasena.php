<?php
include 'conexion.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    
   
    $result = $conn->query("SELECT * FROM usuarios WHERE email='$email'");

    if ($result->num_rows > 0) {
        
        $token = bin2hex(random_bytes(50));
        $expires = date("U") + 1800; // Token válido por 30 minutos

        
        $conn->query("UPDATE usuarios SET reset_token='$token', reset_token_expire='$expires' WHERE email='$email'");

       
        $url = "http://yourdomain.com/restablecer_contrasena.php?token=$token";

       
        $to = $email;
        $subject = "Restablece tu contraseña - Supermercado";
        $message = "<p>Hemos recibido una solicitud para restablecer tu contraseña. Si no fuiste tú, ignora este correo.</p>";
        $message .= "<p>Aquí está tu enlace de restablecimiento de contraseña:</p>";
        $message .= "<a href='" . $url . "'>Haz clic aquí para restablecer tu contraseña</a>";

        $headers = "From: no-reply@supermercado.com\r\n";
        $headers .= "Reply-To: no-reply@supermercado.com\r\n";
        $headers .= "Content-type: text/html\r\n";

        mail($to, $subject, $message, $headers);

        echo "Correo enviado. Por favor, revisa tu bandeja de entrada.";
    } else {
        echo "No se encontró ninguna cuenta con ese correo.";
    }
}

$conn->close();
?>
