<?php
include 'conexion.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $nueva_contrasena = password_hash($_POST['contrasena'], PASSWORD_BCRYPT);

    $sql = "SELECT email FROM tokens_reset WHERE token = '$token'";
    $resultado = $conexion->query($sql);

    if ($resultado->num_rows > 0) {
        $usuario = $resultado->fetch_assoc();
        $email = $usuario['email'];

        $sql = "UPDATE usuarios SET contrasena='$nueva_contrasena' WHERE email='$email'";
        if ($conexion->query($sql) === TRUE) {
            echo "Contraseña actualizada correctamente. <a href='iniciar_sesion.php'>Inicia sesión</a>";
        } else {
            echo "Error: " . $sql . "<br>" . $conexion->error;
        }

        $sql = "DELETE FROM tokens_reset WHERE token='$token'";
        $conexion->query($sql);
    } else {
        echo "Token no válido.";
    }
}
?>
