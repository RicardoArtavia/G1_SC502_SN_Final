<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sección de Productos</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 90%;
            margin: auto;
            overflow: hidden;
        }

        h2 {
            text-align: center;
            margin: 20px 0;
            color: #333;
        }

        .productos-contenedor {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .producto-caja {
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .producto-caja:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }

        .producto-caja img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 15px;
            transition: transform 0.3s ease;
        }

        .producto-caja img:hover {
            transform: scale(1.05);
        }

        .producto-caja h3 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }

        .producto-caja p.precio {
            font-size: 18px;
            color: #74a916;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .boton-agregar-carrito {
            background-color: #74a916;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        .boton-agregar-carrito:hover {
            background-color: #9bce21;
        }

        .boton-regresar {
            background-color: #74a916;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            margin: 20px 0;
        }

        .boton-regresar:hover {
            background-color: #555;
        }
    </style>
</head>
<body>

<div class="container">
    <a href="index.php" class="boton-regresar"><i class="fas fa-arrow-left"></i> Regresar</a>
    <h2>Productos</h2>
    <div class="productos-contenedor">
        <!-- Producto 1 -->
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P30.png" alt="Sal">
            <h3>Sal</h3>
            <p class="precio">₡800</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="1">
                <input type="hidden" name="producto_nombre" value="Sal">
                <input type="hidden" name="producto_precio" value="800">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

        
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P31.png" alt="Frijoles Negros">
            <h3>Frijoles Negros</h3>
            <p class="precio">₡1800</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="2">
                <input type="hidden" name="producto_nombre" value="Frijoles Negros">
                <input type="hidden" name="producto_precio" value="1800">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

     
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P32.png" alt="Lizano">
            <h3>Lizano</h3>
            <p class="precio">₡1200</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="3">
                <input type="hidden" name="producto_nombre" value="Lizano">
                <input type="hidden" name="producto_precio" value="1200">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

        
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P33.png" alt="Café 1820">
            <h3>Café 1820</h3>
            <p class="precio">₡3000</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="4">
                <input type="hidden" name="producto_nombre" value="Café 1820">
                <input type="hidden" name="producto_precio" value="3000">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

        <!-- Producto 5 -->
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P34.png" alt="Caracolitos">
            <h3>Caracolitos</h3>
            <p class="precio">₡760</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="5">
                <input type="hidden" name="producto_nombre" value="Caracolitos">
                <input type="hidden" name="producto_precio" value="760">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

        <!-- Producto 6 -->
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P35.png" alt="Azúcar">
            <h3>Azúcar</h3>
            <p class="precio">₡1800</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="6">
                <input type="hidden" name="producto_nombre" value="Azúcar">
                <input type="hidden" name="producto_precio" value="1800">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

        <!-- Producto 7 -->
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P43.png" alt="Bolsas de Basura">
            <h3>Bolsas de Basura</h3>
            <p class="precio">₡1300</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="7">
                <input type="hidden" name="producto_nombre" value="Bolsas de Basura">
                <input type="hidden" name="producto_precio" value="1300">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

        
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P37.png" alt="Nestum">
            <h3>Nestum</h3>
            <p class="precio">₡2700</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="8">
                <input type="hidden" name="producto_nombre" value="Nestum">
                <input type="hidden" name="producto_precio" value="2700">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

        
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P38.png" alt="Dental Care">
            <h3>Dental Care</h3>
            <p class="precio">₡1200</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="9">
                <input type="hidden" name="producto_nombre" value="Dental Care">
                <input type="hidden" name="producto_precio" value="1200">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

   
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P39.png" alt="Purina Cat Chow">
            <h3>Purina Cat Chow</h3>
            <p class="precio">₡5600</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="10">
                <input type="hidden" name="producto_nombre" value="Purina Cat Chow">
                <input type="hidden" name="producto_precio" value="5600">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

       
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/p3.png" alt="Queso Turrialba">
            <h3>Queso Turrialba</h3>
            <p class="precio">₡4000</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="11">
                <input type="hidden" name="producto_nombre" value="Queso Turrialba">
                <input type="hidden" name="producto_precio" value="4000">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

       
        <div class="producto-caja">
            <img src="FOTOS DEL SUPER/P42.png" alt="Servilletas de Cocina">
            <h3>Servilletas de Cocina</h3>
            <p class="precio">₡2000</p>
            <form action="agregar_carrito.php" method="post">
                <input type="hidden" name="producto_id" value="12">
                <input type="hidden" name="producto_nombre" value="Servilletas de Cocina">
                <input type="hidden" name="producto_precio" value="2000">
                <button type="submit" class="boton-agregar-carrito">Agregar al carrito</button>
            </form>
        </div>

    </div>
</div>

</body>
</html>
