<?php
require 'conexion.php';

$mensaje_exito = "";
$mensaje_error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST['email']);

   
    $sql = "SELECT * FROM usuarios WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $token = bin2hex(random_bytes(50)); // Crear un token de restablecimiento
        $expire = date('Y-m-d H:i:s', strtotime('+1 hour')); // El token expira en 1 hora

       
        $sql = "UPDATE usuarios SET reset_token='$token', reset_token_expire='$expire' WHERE email='$email'";
        if ($conn->query($sql) === TRUE) {
            
            $reset_link = "http://localhost/tu_proyecto/restablecer_contraseña.php?token=$token"; // Cambia "tu_proyecto" por la carpeta de tu proyecto

            $subject = 'Restablecimiento de contraseña';
            $message = "Hola,\n\nHaz clic en el siguiente enlace para restablecer tu contraseña:\n$reset_link\n\nEste enlace expirará en una hora.";
            $headers = 'From: supermercado198@gmail.com' . "\r\n" .
                       'Reply-To: supermercado198@gmail.com' . "\r\n" .
                       'X-Mailer: PHP/' . phpversion();

            if (mail($email, $subject, $message, $headers)) {
                $mensaje_exito = "Se ha enviado un correo con el enlace para restablecer tu contraseña.";
            } else {
                $mensaje_error = "Hubo un problema al enviar el correo.";
            }
        } else {
            $mensaje_error = "Hubo un problema al generar el enlace de restablecimiento.";
        }
    } else {
        $mensaje_error = "No existe una cuenta con ese correo electrónico.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .form-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            margin-bottom: 20px;
        }

        .form-container label {
            display: block;
            margin-bottom: 8px;
        }

        .form-container input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #0056b3;
        }

        .message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Recuperar Contraseña</h2>
        <form action="recuperar_contraseña.php" method="POST">
            <label for="email">Correo Electrónico</label>
            <input type="email" id="email" name="email" required>
            <button type="submit">Enviar Enlace de Restablecimiento</button>
        </form>

        <?php if (!empty($mensaje_exito)): ?>
            <div class="message success-message">
                <?php echo $mensaje_exito; ?>
            </div>
        <?php elseif (!empty($mensaje_error)): ?>
            <div class="message error-message">
                <?php echo $mensaje_error; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

