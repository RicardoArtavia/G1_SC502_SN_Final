<?php
require 'conexion.php';

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $conn->real_escape_string($_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Verificar si el correo ya existe
    $checkEmailQuery = "SELECT * FROM usuarios WHERE email='$email'";
    $checkEmailResult = $conn->query($checkEmailQuery);

    if ($checkEmailResult->num_rows > 0) {
        $mensaje = "Ya existe una cuenta con ese correo electrónico.";
    } else {
        // Insertar nuevo usuario en la base de datos
        $sql = "INSERT INTO usuarios (nombre, email, password) VALUES ('$nombre', '$email', '$hashed_password')";
        if ($conn->query($sql) === TRUE) {
            $mensaje = "Cuenta creada con éxito. Ahora puedes iniciar sesión.";
        } else {
            $mensaje = "Error al crear la cuenta: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <style>
        /* Estilos para el formulario */
        body { font-family: Arial, sans-serif; background-color: #f4f4f4; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .form-container { background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
        .form-container h2 { margin-bottom: 20px; }
        .form-container label { display: block; margin-bottom: 8px; }
        .form-container input[type="text"], .form-container input[type="email"], .form-container input[type="password"] { width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px; }
        .form-container button { width: 100%; padding: 10px; background-color: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .form-container button:hover { background-color: #218838; }
        .message { background-color: #d4edda; color: #155724; padding: 10px; margin-top: 20px; border: 1px solid #c3e6cb; border-radius: 5px; text-align: center; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Crear Cuenta</h2>
        <form action="registro.php" method="POST">
            <label for="nombre">Nombre</label>
            <input type="text" id="nombre" name="nombre" required>
            <label for="email">Correo Electrónico</label>
            <input type="email" id="email" name="email" required>
            <label for="password">Contraseña</label>
            <input type="password" id="password" name="password" required>
            <button type="submit">Crear Cuenta</button>
        </form>

        <?php if (!empty($mensaje)): ?>
            <div class="message">
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
tml>
