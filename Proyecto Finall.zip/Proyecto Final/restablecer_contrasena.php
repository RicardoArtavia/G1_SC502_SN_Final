<?php
require 'conexion.php';

$mensaje_exito = "";
$mensaje_error = "";

if (isset($_GET['token'])) {
    $token = $conn->real_escape_string($_GET['token']);

    // Verificar si el token es válido y no ha expirado
    $sql = "SELECT * FROM usuarios WHERE reset_token='$token' AND reset_token_expire > NOW()";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $password = password_hash($conn->real_escape_string($_POST['password']), PASSWORD_BCRYPT);

            // Restablecer la contraseña y eliminar el token
            $sql = "UPDATE usuarios SET password='$password', reset_token=NULL, reset_token_expire=NULL WHERE reset_token='$token'";
            if ($conn->query($sql) === TRUE) {
                $mensaje_exito = "Tu contraseña ha sido restablecida exitosamente.";
            } else {
                $mensaje_error = "Hubo un problema al restablecer tu contraseña.";
            }
        }
    } else {
        $mensaje_error = "El enlace de restablecimiento no es válido o ha expirado.";
    }
} else {
    $mensaje_error = "No se proporcionó un token válido.";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restablecer Contraseña</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .form-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .form-container h2 {
            margin-bottom: 20px;
        }

        .form-container label {
            display: block;
            margin-bottom: 8px;
        }

        .form-container input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-container button {
            width: 100%;
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #218838;
        }

        .message {
            margin-top: 20px;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Restablecer Contraseña</h2>
        <?php if (!empty($mensaje_exito)): ?>
            <div class="message success-message">
                <?php echo $mensaje_exito; ?>
            </div>
        <?php elseif (!empty($mensaje_error)): ?>
            <div class="message error-message">
                <?php echo $mensaje_error; ?>
            </div>
        <?php else: ?>
            <form action="" method="POST">
                <label for="password">Nueva Contraseña</label>
                <input type="password" id="password" name="password" required>
                <button type="submit">Restablecer Contraseña</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
