console.log("JavaScript está funcionando");

document.addEventListener('DOMContentLoaded', () => {
    // Funcionalidad para "Cargar Más" productos
    const loadMoreBtn = document.getElementById('load-more');
    const products = document.querySelectorAll('.box-container .box');
    let visibleItems = 8; // Número inicial de productos visibles

    console.log("Número de productos detectados:", products.length);

    if (!loadMoreBtn) {
        console.error("El botón 'Cargar Más' no se encontró en el DOM.");
        return;
    }
    
    if (products.length === 0) {
        console.error("No se encontraron productos en '.box-container .box'.");
        return;
    }

    loadMoreBtn.addEventListener('click', () => {
        visibleItems += 4; // Incrementar el número de productos visibles en 4
        const totalItems = products.length;

        for (let i = 0; i < totalItems; i++) {
            if (i < visibleItems) {
                products[i].style.display = 'inline-block';
            }
        }

        // Ocultar el botón si todos los productos son visibles
        if (visibleItems >= totalItems) {
            loadMoreBtn.style.display = 'none';
        }
    });

    // Funcionalidad para Preguntas Frecuentes
    const faqButtons = document.querySelectorAll('.faq-button');

    faqButtons.forEach(button => {
        button.addEventListener('click', function() {
            const faqContent = button.nextElementSibling;

            // Si la respuesta ya está visible, se oculta
            if (faqContent.style.display === 'block') {
                faqContent.style.display = 'none';
            } else {
                // Primero oculta todas las respuestas
                document.querySelectorAll('.faq-content').forEach(content => {
                    content.style.display = 'none';
                });

                // Luego muestra la respuesta seleccionada
                faqContent.style.display = 'block';
            }
        });
    });
});