<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php'); // Redirige a la página de inicio de sesión si no está logueado
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Transporte</title>
</head>
<body>
    <h2>Selecciona una opción de transporte</h2>
    <form action="finalizar_compra.php" method="post">
        <label>
            <input type="radio" name="transporte" value="Entrega Rápida" required> Entrega Rápida
        </label><br>
        <label>
            <input type="radio" name="transporte" value="Entrega Normal" required> Entrega Normal
        </label><br>
        <label>
            <input type="radio" name="transporte" value="Recoger en Tienda" required> Recoger en Tienda
        </label><br><br>
        <button type="submit">Finalizar Compra</button>
    </form>
</body>
</html>
